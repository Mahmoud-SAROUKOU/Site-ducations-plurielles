<?php

/**
 * API - Réinitialisation de mot de passe (style WordPress)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

$action = $input['action'] ?? '';

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../mailer.php';

$pdo = Database::connect();

function jsonResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function formatExpiresLabel(string $expiresAt): string
{
    $timestamp = strtotime($expiresAt);
    if (!$timestamp) {
        return '—';
    }
    return date('d/m/Y \à H:i', $timestamp);
}

switch ($action) {
    case 'request_reset':
        $email = trim(strtolower($input['email'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'message' => 'Email invalide.'], 400);
        }

        $stmt = $pdo->prepare('SELECT id, nom, email FROM admins WHERE email = ? AND actif = 1');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if (!$admin) {
            jsonResponse([
                'success' => true,
                'message' => 'Si l’email existe, un lien de réinitialisation a été envoyé.',
                'email_status' => ['sent' => false, 'queued' => false]
            ]);
        }

        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $expiresAt = date('Y-m-d H:i:s', time() + (24 * 60 * 60));

        $pdo->prepare('UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE admin_id = ? AND used_at IS NULL')
            ->execute([$admin['id']]);

        $stmt = $pdo->prepare(
            'INSERT INTO password_resets (admin_id, token_hash, expires_at, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $admin['id'],
            $tokenHash,
            $expiresAt,
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        $resetUrl = rtrim(APP_URL, '/') . '/admin/reset-password.php?token=' . urlencode($token);
        $expiresLabel = formatExpiresLabel($expiresAt);
        Mailer::sendPasswordResetEmail($admin['nom'], $admin['email'], $resetUrl, $expiresLabel);
        $status = Mailer::getLastSendStatus();

        jsonResponse([
            'success' => true,
            'message' => 'Lien de réinitialisation envoyé.',
            'email_status' => $status
        ]);
        break;

    case 'verify_token':
        $token = trim($input['token'] ?? '');
        if ($token === '') {
            jsonResponse(['success' => false, 'message' => 'Token manquant.'], 400);
        }

        $tokenHash = hash('sha256', $token);
        $stmt = $pdo->prepare('SELECT pr.id, pr.expires_at, a.nom, a.email FROM password_resets pr JOIN admins a ON a.id = pr.admin_id WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > ?');
        $stmt->execute([$tokenHash, date('Y-m-d H:i:s')]);
        $reset = $stmt->fetch();

        if (!$reset) {
            jsonResponse(['success' => false, 'message' => 'Lien expiré ou invalide.']);
        }

        jsonResponse([
            'success' => true,
            'message' => 'Lien valide.',
            'admin' => [
                'name' => $reset['nom'],
                'email' => $reset['email']
            ],
            'expires_at' => $reset['expires_at']
        ]);
        break;

    case 'reset_password':
        $token = trim($input['token'] ?? '');
        $password = $input['password'] ?? '';

        if ($token === '' || $password === '') {
            jsonResponse(['success' => false, 'message' => 'Token et mot de passe requis.'], 400);
        }

        if (strlen($password) < 6) {
            jsonResponse(['success' => false, 'message' => 'Mot de passe trop court (min 6 caractères).'], 400);
        }

        $tokenHash = hash('sha256', $token);
        $stmt = $pdo->prepare('SELECT pr.id, pr.admin_id FROM password_resets pr WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > ?');
        $stmt->execute([$tokenHash, date('Y-m-d H:i:s')]);
        $reset = $stmt->fetch();

        if (!$reset) {
            jsonResponse(['success' => false, 'message' => 'Lien expiré ou invalide.'], 400);
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $pdo->prepare('UPDATE admins SET password_hash = ? WHERE id = ?')->execute([$hash, $reset['admin_id']]);
        $pdo->prepare('UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$reset['id']]);
        $pdo->prepare('DELETE FROM sessions WHERE admin_id = ?')->execute([$reset['admin_id']]);

        jsonResponse(['success' => true, 'message' => 'Mot de passe réinitialisé avec succès.']);
        break;

    default:
        jsonResponse(['success' => false, 'message' => 'Action invalide.'], 400);
}
