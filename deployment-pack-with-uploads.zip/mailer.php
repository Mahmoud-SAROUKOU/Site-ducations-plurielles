<?php

/**
 * SYSTÈME D'ENVOI D'EMAIL
 * Envoi d'emails de bienvenue aux administrateurs
 */

class Mailer
{
    private static array $lastSendStatus = [
        'sent' => false,
        'queued' => false,
        'error' => ''
    ];

    public static function getLastSendStatus(): array
    {
        return self::$lastSendStatus;
    }

    private static function setLastSendStatus(bool $sent, bool $queued, string $error = ''): void
    {
        self::$lastSendStatus = [
            'sent' => $sent,
            'queued' => $queued,
            'error' => $error
        ];
    }

    /**
     * Envoie un email de bienvenue à un nouvel administrateur
     */
    public static function sendWelcomeEmail(string $nom, string $email, string $password): bool
    {
        return self::sendWelcomeEmailCore($nom, $email, $password, true);
    }

    /**
     * Envoie un email de bienvenue avec lien de réinitialisation (style WordPress)
     */
    public static function sendWelcomeEmailWithReset(string $nom, string $email, string $password, string $resetUrl, string $expiresLabel, string $loginUrl): bool
    {
        return self::sendWelcomeEmailWithResetCore($nom, $email, $password, $resetUrl, $expiresLabel, $loginUrl, true);
    }

    /**
     * Envoie un email de réinitialisation de mot de passe
     */
    public static function sendPasswordResetEmail(string $nom, string $email, string $resetUrl, string $expiresLabel): bool
    {
        return self::sendPasswordResetEmailCore($nom, $email, $resetUrl, $expiresLabel, true);
    }

    private static function sendWelcomeEmailCore(string $nom, string $email, string $password, bool $allowQueue): bool
    {
        $subject = '🎉 Bienvenue sur ' . MAIL_FROM_NAME;

        $loginUrl = APP_URL . '/admin.html';

        $textBody = self::getEmailTemplateText($nom, $email, $password, $loginUrl);
        $htmlBody = self::getEmailTemplateHtml($nom, $email, $password, $loginUrl);

        // En développement : afficher l'email dans les logs
        if (!MAIL_SMTP_HOST) {
            if ($allowQueue) {
                self::queueEmail('welcome', [
                    'name' => $nom,
                    'email' => $email,
                    'password' => $password
                ], 'SMTP non configuré');
                self::setLastSendStatus(false, true, 'SMTP non configuré');
                return false;
            }

            error_log("=== EMAIL DE BIENVENUE ===\n" .
                "À: {$nom} <{$email}>\n" .
                "Sujet: {$subject}\n" .
                "---\n{$textBody}\n" .
                "==================\n");

            // Sauvegarder dans un fichier
            $file = __DIR__ . '/emails.log';
            $log = "\n\n" . date('Y-m-d H:i:s') . "\n";
            $log .= "À: {$nom} <{$email}>\n";
            $log .= "Sujet: {$subject}\n";
            $log .= "---\n{$textBody}\n";
            $log .= str_repeat('=', 60) . "\n";
            file_put_contents($file, $log, FILE_APPEND);

            self::setLastSendStatus(true, false, '');
            return true;
        }

        // En production : envoi SMTP réel
        $sent = self::sendSMTP($email, $nom, $subject, $htmlBody, $textBody);
        if (!$sent) {
            if ($allowQueue) {
                self::queueEmail('welcome', [
                    'name' => $nom,
                    'email' => $email,
                    'password' => $password
                ], 'Échec SMTP');
                self::setLastSendStatus(false, true, 'Échec SMTP');
                return false;
            }

            $file = __DIR__ . '/emails.log';
            $log = "\n\n" . date('Y-m-d H:i:s') . "\n";
            $log .= "ÉCHEC ENVOI SMTP\n";
            $log .= "À: {$nom} <{$email}>\n";
            $log .= "Sujet: {$subject}\n";
            $log .= "---\n{$textBody}\n";
            $log .= str_repeat('=', 60) . "\n";
            file_put_contents($file, $log, FILE_APPEND);
        }

        self::setLastSendStatus($sent, false, $sent ? '' : 'Échec SMTP');

        return $sent;
    }

    private static function sendWelcomeEmailWithResetCore(string $nom, string $email, string $password, string $resetUrl, string $expiresLabel, string $loginUrl, bool $allowQueue): bool
    {
        $subject = '🎉 Bienvenue sur ' . MAIL_FROM_NAME;

        $textBody = self::getWelcomeWithResetTemplateText($nom, $email, $password, $resetUrl, $expiresLabel, $loginUrl);
        $htmlBody = self::getWelcomeWithResetTemplateHtml($nom, $email, $password, $resetUrl, $expiresLabel, $loginUrl);

        if (!MAIL_SMTP_HOST) {
            if ($allowQueue) {
                self::queueEmail('welcome_reset', [
                    'name' => $nom,
                    'email' => $email,
                    'password' => $password,
                    'reset_url' => $resetUrl,
                    'expires_label' => $expiresLabel,
                    'login_url' => $loginUrl
                ], 'SMTP non configuré');
                self::setLastSendStatus(false, true, 'SMTP non configuré');
                return false;
            }

            error_log("=== EMAIL BIENVENUE + RESET ===\n" .
                "À: {$nom} <{$email}>\n" .
                "Sujet: {$subject}\n" .
                "---\n{$textBody}\n" .
                "==================\n");

            $file = __DIR__ . '/emails.log';
            $log = "\n\n" . date('Y-m-d H:i:s') . "\n";
            $log .= "À: {$nom} <{$email}>\n";
            $log .= "Sujet: {$subject}\n";
            $log .= "---\n{$textBody}\n";
            $log .= str_repeat('=', 60) . "\n";
            file_put_contents($file, $log, FILE_APPEND);

            self::setLastSendStatus(true, false, '');
            return true;
        }

        $sent = self::sendSMTP($email, $nom, $subject, $htmlBody, $textBody);
        if (!$sent) {
            if ($allowQueue) {
                self::queueEmail('welcome_reset', [
                    'name' => $nom,
                    'email' => $email,
                    'password' => $password,
                    'reset_url' => $resetUrl,
                    'expires_label' => $expiresLabel,
                    'login_url' => $loginUrl
                ], 'Échec SMTP');
                self::setLastSendStatus(false, true, 'Échec SMTP');
                return false;
            }

            $file = __DIR__ . '/emails.log';
            $log = "\n\n" . date('Y-m-d H:i:s') . "\n";
            $log .= "ÉCHEC ENVOI SMTP\n";
            $log .= "À: {$nom} <{$email}>\n";
            $log .= "Sujet: {$subject}\n";
            $log .= "---\n{$textBody}\n";
            $log .= str_repeat('=', 60) . "\n";
            file_put_contents($file, $log, FILE_APPEND);
        }

        self::setLastSendStatus($sent, false, $sent ? '' : 'Échec SMTP');

        return $sent;
    }

    private static function sendPasswordResetEmailCore(string $nom, string $email, string $resetUrl, string $expiresLabel, bool $allowQueue): bool
    {
        $subject = '🔐 Réinitialiser votre mot de passe - ' . MAIL_FROM_NAME;

        $textBody = self::getResetEmailTemplateText($nom, $resetUrl, $expiresLabel);
        $htmlBody = self::getResetEmailTemplateHtml($nom, $resetUrl, $expiresLabel);

        if (!MAIL_SMTP_HOST) {
            if ($allowQueue) {
                self::queueEmail('reset', [
                    'name' => $nom,
                    'email' => $email,
                    'reset_url' => $resetUrl,
                    'expires_label' => $expiresLabel
                ], 'SMTP non configuré');
                self::setLastSendStatus(false, true, 'SMTP non configuré');
                return false;
            }

            error_log("=== EMAIL RESET ===\n" .
                "À: {$nom} <{$email}>\n" .
                "Sujet: {$subject}\n" .
                "---\n{$textBody}\n" .
                "==================\n");

            $file = __DIR__ . '/emails.log';
            $log = "\n\n" . date('Y-m-d H:i:s') . "\n";
            $log .= "À: {$nom} <{$email}>\n";
            $log .= "Sujet: {$subject}\n";
            $log .= "---\n{$textBody}\n";
            $log .= str_repeat('=', 60) . "\n";
            file_put_contents($file, $log, FILE_APPEND);

            self::setLastSendStatus(true, false, '');
            return true;
        }

        $sent = self::sendSMTP($email, $nom, $subject, $htmlBody, $textBody);
        if (!$sent) {
            if ($allowQueue) {
                self::queueEmail('reset', [
                    'name' => $nom,
                    'email' => $email,
                    'reset_url' => $resetUrl,
                    'expires_label' => $expiresLabel
                ], 'Échec SMTP');
                self::setLastSendStatus(false, true, 'Échec SMTP');
                return false;
            }

            $file = __DIR__ . '/emails.log';
            $log = "\n\n" . date('Y-m-d H:i:s') . "\n";
            $log .= "ÉCHEC ENVOI SMTP\n";
            $log .= "À: {$nom} <{$email}>\n";
            $log .= "Sujet: {$subject}\n";
            $log .= "---\n{$textBody}\n";
            $log .= str_repeat('=', 60) . "\n";
            file_put_contents($file, $log, FILE_APPEND);
        }

        self::setLastSendStatus($sent, false, $sent ? '' : 'Échec SMTP');

        return $sent;
    }

    private static function queueEmail(string $type, array $payload, string $reason = ''): void
    {
        $queue = self::loadQueue();
        $queue[] = [
            'id' => uniqid('email_', true),
            'type' => $type,
            'payload' => $payload,
            'attempts' => 0,
            'last_error' => $reason,
            'created_at' => date('c')
        ];
        self::saveQueue($queue);
    }

    private static function loadQueue(): array
    {
        $path = self::getQueuePath();
        if (!file_exists($path)) {
            return [];
        }

        $raw = file_get_contents($path);
        $data = json_decode($raw ?: '[]', true);
        return is_array($data) ? $data : [];
    }

    private static function saveQueue(array $queue): void
    {
        $path = self::getQueuePath();
        file_put_contents($path, json_encode($queue, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    private static function getQueuePath(): string
    {
        return __DIR__ . '/email-queue.json';
    }

    public static function processQueue(int $limit = 20): array
    {
        $queue = self::loadQueue();
        $sent = 0;
        $failed = 0;
        $processed = 0;

        $remaining = [];

        foreach ($queue as $item) {
            if ($processed >= $limit) {
                $remaining[] = $item;
                continue;
            }

            $processed++;
            $success = false;
            $error = '';

            if ($item['type'] === 'welcome') {
                $payload = $item['payload'] ?? [];
                $success = self::sendWelcomeEmailCore(
                    $payload['name'] ?? '',
                    $payload['email'] ?? '',
                    $payload['password'] ?? '',
                    false
                );
                $status = self::getLastSendStatus();
                $error = $status['error'] ?? '';
            } elseif ($item['type'] === 'welcome_reset') {
                $payload = $item['payload'] ?? [];
                $success = self::sendWelcomeEmailWithResetCore(
                    $payload['name'] ?? '',
                    $payload['email'] ?? '',
                    $payload['password'] ?? '',
                    $payload['reset_url'] ?? '',
                    $payload['expires_label'] ?? '',
                    $payload['login_url'] ?? '',
                    false
                );
                $status = self::getLastSendStatus();
                $error = $status['error'] ?? '';
            } elseif ($item['type'] === 'reset') {
                $payload = $item['payload'] ?? [];
                $success = self::sendPasswordResetEmailCore(
                    $payload['name'] ?? '',
                    $payload['email'] ?? '',
                    $payload['reset_url'] ?? '',
                    $payload['expires_label'] ?? '',
                    false
                );
                $status = self::getLastSendStatus();
                $error = $status['error'] ?? '';
            } else {
                $error = 'Type non supporté';
            }

            if ($success) {
                $sent++;
            } else {
                $item['attempts'] = ($item['attempts'] ?? 0) + 1;
                $item['last_error'] = $error ?: 'Échec envoi';
                $remaining[] = $item;
                $failed++;
            }
        }

        self::saveQueue($remaining);

        return [
            'processed' => $processed,
            'sent' => $sent,
            'failed' => $failed,
            'remaining' => count($remaining)
        ];
    }

    public static function getQueueCount(): int
    {
        return count(self::loadQueue());
    }

    /**
     * Template d'email de bienvenue (style WordPress)
     */
    private static function getEmailTemplateText(string $nom, string $email, string $password, string $loginUrl): string
    {
        return "Bonjour {$nom},

Bienvenue sur " . MAIL_FROM_NAME . " !

Votre compte administrateur a été créé avec succès. Vous pouvez maintenant vous connecter à l'interface d'administration avec les informations suivantes :

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔐 VOS IDENTIFIANTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Nom d'utilisateur : {$email}
Mot de passe : {$password}
URL de connexion : {$loginUrl}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ IMPORTANT : Pour des raisons de sécurité, nous vous recommandons fortement de changer votre mot de passe lors de votre première connexion.

Pour vous connecter :
1. Rendez-vous sur : {$loginUrl}
2. Connectez-vous avec les identifiants ci-dessus
3. Accédez aux paramètres pour changer votre mot de passe

Si vous avez des questions ou besoin d'aide, n'hésitez pas à nous contacter.

Cordialement,
L'équipe " . MAIL_FROM_NAME . "

---
Cet email a été envoyé automatiquement, merci de ne pas y répondre.
";
    }

    /**
     * Template HTML premium
     */
    private static function getEmailTemplateHtml(string $nom, string $email, string $password, string $loginUrl): string
    {
        $appName = MAIL_FROM_NAME;
        $safeName = htmlspecialchars($nom, ENT_QUOTES, 'UTF-8');
        $safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
        $safePassword = htmlspecialchars($password, ENT_QUOTES, 'UTF-8');
        $safeLoginUrl = htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8');

        return <<<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue sur {$appName}</title>
</head>
<body style="margin:0; padding:0; background:#f5f7fb; font-family:Arial, Helvetica, sans-serif; color:#1f2937;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f5f7fb; padding:24px 0;">
        <tr>
            <td align="center">
                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 10px 30px rgba(15,23,42,0.08);">
                    <tr>
                        <td style="padding:28px 32px; background:linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color:#fff;">
                            <h1 style="margin:0; font-size:24px;">Bienvenue sur {$appName}</h1>
                            <p style="margin:8px 0 0; opacity:0.9;">Votre compte administrateur est prêt.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:28px 32px;">
                            <p style="margin:0 0 12px;">Bonjour <strong>{$safeName}</strong>,</p>
                            <p style="margin:0 0 18px;">Votre compte administrateur a été créé avec succès. Vous pouvez vous connecter dès maintenant.</p>

                            <div style="background:#f1f5f9; border-radius:10px; padding:16px; border:1px solid #e2e8f0;">
                                <p style="margin:0 0 8px; font-weight:bold;">Vos identifiants</p>
                                <p style="margin:0; font-family:monospace;">Email&nbsp;: {$safeEmail}</p>
                                <p style="margin:6px 0 0; font-family:monospace;">Mot de passe&nbsp;: {$safePassword}</p>
                            </div>

                            <p style="margin:18px 0 12px; color:#b45309; background:#fffbeb; border-left:4px solid #f59e0b; padding:12px; border-radius:8px;">
                                ⚠️ Pensez à changer votre mot de passe dès votre première connexion.
                            </p>

                            <a href="{$safeLoginUrl}" style="display:inline-block; background:#1e3a8a; color:#fff; text-decoration:none; padding:12px 20px; border-radius:8px;">Se connecter</a>

                            <p style="margin:20px 0 0; font-size:13px; color:#64748b;">Si vous avez des questions, contactez l’administrateur principal.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:16px 32px; background:#f8fafc; font-size:12px; color:#94a3b8; text-align:center;">
                            {$appName} © 2026 — Email automatique, merci de ne pas répondre.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;
    }

    private static function getResetEmailTemplateText(string $nom, string $resetUrl, string $expiresLabel): string
    {
        return "Bonjour {$nom},

Une demande de réinitialisation de mot de passe a été reçue.

Pour définir un nouveau mot de passe, cliquez sur le lien ci-dessous :
{$resetUrl}

Ce lien expire le {$expiresLabel}.

Si vous n'êtes pas à l'origine de cette demande, ignorez simplement cet email.

Cordialement,
L'équipe " . MAIL_FROM_NAME . "

---
Cet email a été envoyé automatiquement, merci de ne pas y répondre.
";
    }

    private static function getResetEmailTemplateHtml(string $nom, string $resetUrl, string $expiresLabel): string
    {
        $appName = MAIL_FROM_NAME;
        $safeName = htmlspecialchars($nom, ENT_QUOTES, 'UTF-8');
        $safeResetUrl = htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8');
        $safeExpires = htmlspecialchars($expiresLabel, ENT_QUOTES, 'UTF-8');

        return <<<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe</title>
</head>
<body style="margin:0; padding:0; background:#f5f7fb; font-family:Arial, Helvetica, sans-serif; color:#1f2937;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f5f7fb; padding:24px 0;">
        <tr>
            <td align="center">
                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 10px 30px rgba(15,23,42,0.08);">
                    <tr>
                        <td style="padding:28px 32px; background:linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color:#fff;">
                            <h1 style="margin:0; font-size:24px;">Réinitialiser votre mot de passe</h1>
                            <p style="margin:8px 0 0; opacity:0.9;">{$appName}</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:28px 32px;">
                            <p style="margin:0 0 12px;">Bonjour <strong>{$safeName}</strong>,</p>
                            <p style="margin:0 0 18px;">Une demande de réinitialisation de mot de passe a été reçue.</p>

                            <a href="{$safeResetUrl}" style="display:inline-block; background:#1e3a8a; color:#fff; text-decoration:none; padding:12px 20px; border-radius:8px;">Réinitialiser le mot de passe</a>

                            <p style="margin:16px 0 0; color:#64748b;">Ce lien expire le <strong>{$safeExpires}</strong>.</p>
                            <p style="margin:16px 0 0; font-size:13px; color:#64748b;">Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:16px 32px; background:#f8fafc; font-size:12px; color:#94a3b8; text-align:center;">
                            {$appName} © 2026 — Email automatique, merci de ne pas répondre.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;
    }

    private static function getWelcomeWithResetTemplateText(string $nom, string $email, string $password, string $resetUrl, string $expiresLabel, string $loginUrl): string
    {
        return "Bonjour {$nom},

Bienvenue sur " . MAIL_FROM_NAME . " !

Votre compte administrateur a été créé. Voici vos identifiants :

Email : {$email}
Mot de passe temporaire : {$password}

Pour sécuriser votre compte, merci de réinitialiser votre mot de passe via ce lien :
{$resetUrl}

Ce lien expire le {$expiresLabel}.

Connexion : {$loginUrl}

Cordialement,
L'équipe " . MAIL_FROM_NAME . "

---
Cet email a été envoyé automatiquement, merci de ne pas y répondre.
";
    }

    private static function getWelcomeWithResetTemplateHtml(string $nom, string $email, string $password, string $resetUrl, string $expiresLabel, string $loginUrl): string
    {
        $appName = MAIL_FROM_NAME;
        $safeName = htmlspecialchars($nom, ENT_QUOTES, 'UTF-8');
        $safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
        $safePassword = htmlspecialchars($password, ENT_QUOTES, 'UTF-8');
        $safeResetUrl = htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8');
        $safeExpires = htmlspecialchars($expiresLabel, ENT_QUOTES, 'UTF-8');
        $safeLoginUrl = htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8');

        return <<<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue sur {$appName}</title>
</head>
<body style="margin:0; padding:0; background:#f5f7fb; font-family:Arial, Helvetica, sans-serif; color:#1f2937;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f5f7fb; padding:24px 0;">
        <tr>
            <td align="center">
                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 10px 30px rgba(15,23,42,0.08);">
                    <tr>
                        <td style="padding:28px 32px; background:linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color:#fff;">
                            <h1 style="margin:0; font-size:24px;">Bienvenue sur {$appName}</h1>
                            <p style="margin:8px 0 0; opacity:0.9;">Votre compte administrateur est prêt.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:28px 32px;">
                            <p style="margin:0 0 12px;">Bonjour <strong>{$safeName}</strong>,</p>
                            <p style="margin:0 0 18px;">Voici vos identifiants temporaires :</p>

                            <div style="background:#f1f5f9; border-radius:10px; padding:16px; border:1px solid #e2e8f0;">
                                <p style="margin:0 0 8px; font-weight:bold;">Identifiants</p>
                                <p style="margin:0; font-family:monospace;">Email&nbsp;: {$safeEmail}</p>
                                <p style="margin:6px 0 0; font-family:monospace;">Mot de passe temporaire&nbsp;: {$safePassword}</p>
                            </div>

                            <p style="margin:18px 0 12px; color:#b45309; background:#fffbeb; border-left:4px solid #f59e0b; padding:12px; border-radius:8px;">
                                🔐 Merci de réinitialiser votre mot de passe dès maintenant pour sécuriser votre compte.
                            </p>

                            <a href="{$safeResetUrl}" style="display:inline-block; background:#1e3a8a; color:#fff; text-decoration:none; padding:12px 20px; border-radius:8px;">Réinitialiser le mot de passe</a>
                            <p style="margin:16px 0 0; color:#64748b;">Ce lien expire le <strong>{$safeExpires}</strong>.</p>

                            <p style="margin:16px 0 0; font-size:13px; color:#64748b;">Connexion : <a href="{$safeLoginUrl}">{$safeLoginUrl}</a></p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:16px 32px; background:#f8fafc; font-size:12px; color:#94a3b8; text-align:center;">
                            {$appName} © 2026 — Email automatique, merci de ne pas répondre.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;
    }

    /**
     * Envoi via SMTP (pour production)
     */
    private static function sendSMTP(string $to, string $toName, string $subject, string $htmlBody, string $textBody): bool
    {
        $autoload = dirname(__DIR__) . '/vendor/autoload.php';
        if (file_exists($autoload)) {
            require_once $autoload;
        }

        $mailerClass = 'PHPMailer\\PHPMailer\\PHPMailer';
        if (class_exists($mailerClass)) {
            try {
                $mail = new $mailerClass(true);
                $mail->CharSet = 'UTF-8';

                $mail->isSMTP();
                $mail->Host = MAIL_SMTP_HOST;
                $mail->Port = (int)MAIL_SMTP_PORT;
                $mail->SMTPAuth = MAIL_SMTP_USER !== '' || MAIL_SMTP_PASS !== '';
                if ($mail->SMTPAuth) {
                    $mail->Username = MAIL_SMTP_USER;
                    $mail->Password = MAIL_SMTP_PASS;
                }
                if (MAIL_SMTP_SECURE !== '') {
                    $mail->SMTPSecure = MAIL_SMTP_SECURE;
                }

                $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
                $mail->addAddress($to, $toName);
                $mail->Subject = $subject;
                $mail->isHTML(true);
                $mail->Body = $htmlBody;
                $mail->AltBody = $textBody;

                $sent = $mail->send();
                if ($sent) {
                    return true;
                }

                error_log('SMTP error: ' . ($mail->ErrorInfo ?: 'Unknown error'));
            } catch (Exception $e) {
                error_log('SMTP exception: ' . $e->getMessage());
            }

            // Si PHPMailer est disponible, ne pas basculer sur mail() avec SMTP configuré
            if (MAIL_SMTP_HOST) {
                return false;
            }
        }

        $headers = "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM . ">\r\n";
        $headers .= "Reply-To: " . MAIL_FROM . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();

        if (MAIL_SMTP_HOST) {
            ini_set('SMTP', MAIL_SMTP_HOST);
        }
        if (MAIL_SMTP_PORT) {
            ini_set('smtp_port', (string) MAIL_SMTP_PORT);
        }

        return mail($to, $subject, $htmlBody, $headers);
    }

    /**
     * Envoie un email de notification de changement de statut
     */
    public static function sendStatusChangeEmail(string $nom, string $email, bool $actif): bool
    {
        $subject = $actif ? '✅ Votre compte a été activé' : '⚠️ Votre compte a été désactivé';

        $body = "Bonjour {$nom},\n\n";

        if ($actif) {
            $loginUrl = APP_URL . '/admin.html';
            $body .= "Votre compte administrateur sur " . MAIL_FROM_NAME . " a été activé.\n\n";
            $body .= "Vous pouvez maintenant vous connecter à l'adresse suivante :\n";
            $body .= $loginUrl . "\n\n";
        } else {
            $body .= "Votre compte administrateur sur " . MAIL_FROM_NAME . " a été désactivé.\n\n";
            $body .= "Si vous pensez qu'il s'agit d'une erreur, veuillez contacter l'administrateur principal.\n\n";
        }

        $body .= "Cordialement,\n";
        $body .= "L'équipe " . MAIL_FROM_NAME;

        // En développement
        if (!MAIL_SMTP_HOST) {
            error_log("Email changement statut: {$email} - " . ($actif ? 'Activé' : 'Désactivé'));
            $file = __DIR__ . '/emails.log';
            file_put_contents($file, "\n" . date('Y-m-d H:i:s') . " - {$subject} - {$email}\n", FILE_APPEND);
            return true;
        }

        return self::sendSMTP($email, $nom, $subject, nl2br($body), $body);
    }
}
