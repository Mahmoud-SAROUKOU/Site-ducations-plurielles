<?php

/**
 * API - Sauvegarde serveur (JSON enregistré sur disque)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Sync-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

Database::connect();

$providedKey = $_SERVER['HTTP_X_ADMIN_SYNC_KEY'] ?? '';
if (ADMIN_SYNC_KEY !== '' && $providedKey !== ADMIN_SYNC_KEY) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Clé de synchronisation invalide']);
    exit;
}

function tableExists(string $table): bool
{
    try {
        if (USE_SQLITE) {
            $stmt = db()->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name = ? LIMIT 1");
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        }

        $stmt = db()->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1");
        $stmt->execute([DB_NAME, $table]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

$tables = [
    'admins',
    'users',
    'articles',
    'ads',
    'categories',
    'publicites',
    'logs',
    'password_resets'
];

$backup = [
    'generated_at' => date('c'),
    'app' => APP_NAME,
    'tables' => []
];

$pdo = db();
foreach ($tables as $table) {
    if (!tableExists($table)) {
        continue;
    }

    $stmt = $pdo->query("SELECT * FROM {$table}");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $backup['tables'][$table] = $rows;
}

$backupDir = __DIR__ . '/../backups';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0775, true);
}

$filename = 'backup-' . date('Ymd-His') . '.json';
$path = $backupDir . DIRECTORY_SEPARATOR . $filename;
file_put_contents($path, json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

$files = glob($backupDir . DIRECTORY_SEPARATOR . 'backup-*.json') ?: [];
if (count($files) > 10) {
    usort($files, fn($a, $b) => filemtime($a) <=> filemtime($b));
    $toDelete = array_slice($files, 0, count($files) - 10);
    foreach ($toDelete as $file) {
        @unlink($file);
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Sauvegarde serveur créée',
    'file' => $filename
]);
