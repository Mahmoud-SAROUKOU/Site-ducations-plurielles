<?php

/**
 * API - Export ZIP (JSON + images)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Sync-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

Database::connect();

$providedKey = $_SERVER['HTTP_X_ADMIN_SYNC_KEY'] ?? '';
if (ADMIN_SYNC_KEY !== '' && $providedKey !== ADMIN_SYNC_KEY) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Clé de synchronisation invalide']);
    exit;
}

if (!class_exists('ZipArchive')) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'ZipArchive non disponible sur le serveur.']);
    exit;
}

function tableExists(string $table): bool
{
    try {
        if (USE_SQLITE) {
            $stmt = db()->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name = ? LIMIT 1");
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        }

        $stmt = db()->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1");
        $stmt->execute([DB_NAME, $table]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

$tables = [
    'admins',
    'users',
    'articles',
    'ads',
    'categories',
    'publicites',
    'logs',
    'password_resets'
];

$backup = [
    'generated_at' => date('c'),
    'app' => APP_NAME,
    'tables' => []
];

$pdo = db();
foreach ($tables as $table) {
    if (!tableExists($table)) {
        continue;
    }

    $stmt = $pdo->query("SELECT * FROM {$table}");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $backup['tables'][$table] = $rows;
}

$tmpDir = sys_get_temp_dir();
$zipName = 'educations-plurielles-backup-' . date('Ymd-His') . '.zip';
$zipPath = $tmpDir . DIRECTORY_SEPARATOR . $zipName;

$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Impossible de créer le ZIP.']);
    exit;
}

$zip->addFromString('backup.json', json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

$uploadsDir = realpath(__DIR__ . '/../../uploads');
if ($uploadsDir && is_dir($uploadsDir)) {
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($uploadsDir, RecursiveDirectoryIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if (!$file->isFile()) {
            continue;
        }
        $filePath = $file->getRealPath();
        if (!$filePath) {
            continue;
        }
        $relativePath = 'uploads/' . ltrim(str_replace($uploadsDir, '', $filePath), DIRECTORY_SEPARATOR);
        $zip->addFile($filePath, $relativePath);
    }
}

$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $zipName . '"');
header('Content-Length: ' . filesize($zipPath));

readfile($zipPath);
@unlink($zipPath);
