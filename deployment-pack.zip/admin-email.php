<?php

/**
 * API - Emails administrateurs (renvoi bienvenue)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

$action = $input['action'] ?? '';

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../mailer.php';

// Initialise les tables si besoin
Database::connect();

function jsonResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function tableExists(string $table): bool
{
    try {
        $stmt = db()->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1");
        $stmt->execute([DB_NAME, $table]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

function createPasswordResetToken(int $adminId): array
{
    $token = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $token);
    $expiresAt = date('Y-m-d H:i:s', time() + (24 * 60 * 60));

    db()->prepare('UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE admin_id = ? AND used_at IS NULL')
        ->execute([$adminId]);

    db()->prepare(
        'INSERT INTO password_resets (admin_id, token_hash, expires_at, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)'
    )->execute([
        $adminId,
        $tokenHash,
        $expiresAt,
        $_SERVER['REMOTE_ADDR'] ?? '',
        $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);

    return ['token' => $token, 'expires_at' => $expiresAt];
}

function formatExpiresLabel(string $expiresAt): string
{
    $timestamp = strtotime($expiresAt);
    if (!$timestamp) {
        return '—';
    }
    return date('d/m/Y \à H:i', $timestamp);
}

switch ($action) {
    case 'resend_welcome':
        $email = trim(strtolower($input['email'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'message' => 'Email invalide.'], 400);
        }

        if (!tableExists('admins')) {
            jsonResponse(['success' => false, 'message' => 'Table admins introuvable.'], 400);
        }

        $stmt = db()->prepare('SELECT id, nom, email FROM admins WHERE email = ? AND actif = 1');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if (!$admin) {
            jsonResponse([
                'success' => true,
                'message' => 'Si l’email existe, un message a été envoyé.',
                'email_status' => ['sent' => false, 'queued' => false]
            ]);
        }

        $newPassword = bin2hex(random_bytes(6));
        $hash = password_hash($newPassword, PASSWORD_BCRYPT);

        $stmt = db()->prepare('UPDATE admins SET password_hash = ? WHERE id = ?');
        $stmt->execute([$hash, $admin['id']]);

        if (tableExists('users')) {
            $stmt = db()->prepare('UPDATE users SET password_hash = ? WHERE email = ?');
            $stmt->execute([$hash, $admin['email']]);
        }

        $loginUrl = rtrim(APP_URL, '/') . '/admin.html';
        $resetUrl = null;
        $expiresLabel = null;

        if (tableExists('password_resets')) {
            $resetData = createPasswordResetToken((int)$admin['id']);
            $resetUrl = rtrim(APP_URL, '/') . '/admin/reset-password.php?token=' . urlencode($resetData['token']);
            $expiresLabel = formatExpiresLabel($resetData['expires_at'] ?? '');
        }

        if ($resetUrl) {
            Mailer::sendWelcomeEmailWithReset($admin['nom'], $admin['email'], $newPassword, $resetUrl, $expiresLabel ?? '—', $loginUrl);
        } else {
            Mailer::sendWelcomeEmail($admin['nom'], $admin['email'], $newPassword);
        }
        $status = Mailer::getLastSendStatus();

        jsonResponse([
            'success' => true,
            'message' => 'Email renvoyé.',
            'email_status' => $status
        ]);
        break;

    default:
        jsonResponse(['success' => false, 'message' => 'Action invalide.'], 400);
}
