<?php

/**
 * API - Sauvegarde complète (JSON)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Sync-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

Database::connect();

$providedKey = $_SERVER['HTTP_X_ADMIN_SYNC_KEY'] ?? '';
if (ADMIN_SYNC_KEY !== '' && $providedKey !== ADMIN_SYNC_KEY) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Clé de synchronisation invalide']);
    exit;
}

$pdo = db();

function tableExists(string $table): bool
{
    try {
        if (USE_SQLITE) {
            $stmt = db()->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name = ? LIMIT 1");
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        }

        $stmt = db()->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1");
        $stmt->execute([DB_NAME, $table]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

$tables = [
    'admins',
    'users',
    'articles',
    'ads',
    'categories',
    'publicites',
    'logs',
    'password_resets'
];

$backup = [
    'generated_at' => date('c'),
    'app' => APP_NAME,
    'tables' => []
];

foreach ($tables as $table) {
    if (!tableExists($table)) {
        continue;
    }

    $stmt = $pdo->query("SELECT * FROM {$table}");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $backup['tables'][$table] = $rows;
}

$filename = 'educations-plurielles-backup-' . date('Ymd-His') . '.json';
header('Content-Disposition: attachment; filename="' . $filename . '"');

echo json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
