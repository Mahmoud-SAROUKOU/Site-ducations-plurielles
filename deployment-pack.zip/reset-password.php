<?php
// Page de réinitialisation de mot de passe (style WordPress)
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialiser le mot de passe</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --wp-primary: #1e3a8a;
            --wp-border: #e2e8f0;
            --wp-bg: #f8fafc;
            --wp-text: #0f172a;
            --wp-muted: #64748b;
            --wp-success: #16a34a;
            --wp-danger: #dc2626;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0; font-family: Inter, Arial, sans-serif; background: var(--wp-bg); color: var(--wp-text);
            display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px;
        }
        .card {
            background: #fff; border: 1px solid var(--wp-border); border-radius: 14px; padding: 28px; max-width: 480px; width: 100%;
            box-shadow: 0 12px 30px rgba(15,23,42,0.08);
        }
        h1 { margin: 0 0 8px; font-size: 22px; }
        p { margin: 0 0 16px; color: var(--wp-muted); font-size: 14px; }
        label { display: block; margin: 12px 0 6px; font-weight: 600; }
        input {
            width: 100%; padding: 10px 12px; border: 1px solid #c7cbd1; border-radius: 8px; font-size: 14px;
        }
        button {
            margin-top: 16px; width: 100%; background: var(--wp-primary); color: #fff; border: none; padding: 12px; border-radius: 8px; cursor: pointer;
            font-size: 14px; font-weight: 600;
        }
        button:disabled { opacity: 0.6; cursor: not-allowed; }
        .notice { margin-top: 12px; padding: 10px 12px; border-radius: 8px; font-size: 13px; }
        .notice.success { background: #e6f6ee; color: var(--wp-success); }
        .notice.error { background: #fde8e8; color: var(--wp-danger); }
        .footer { margin-top: 16px; text-align: center; font-size: 12px; color: var(--wp-muted); }
        .footer a { color: var(--wp-primary); text-decoration: none; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Réinitialiser votre mot de passe</h1>
        <p>Choisissez un nouveau mot de passe pour votre compte administrateur.</p>

        <form id="resetForm">
            <label for="newPassword">Nouveau mot de passe</label>
            <input type="password" id="newPassword" required minlength="6" placeholder="Mot de passe sécurisé">

            <label for="confirmPassword">Confirmer le mot de passe</label>
            <input type="password" id="confirmPassword" required minlength="6" placeholder="Répétez le mot de passe">

            <button type="submit" id="submitBtn">Réinitialiser</button>
        </form>

        <div id="notice" class="notice" style="display:none;"></div>
        <div class="footer">
            <a href="../admin.html">Retour à l’administration</a>
        </div>
    </div>

    <script>
        const token = new URLSearchParams(window.location.search).get('token') || '';
        const notice = document.getElementById('notice');
        const submitBtn = document.getElementById('submitBtn');

        function showNotice(message, type = 'success') {
            notice.textContent = message;
            notice.className = `notice ${type}`;
            notice.style.display = 'block';
        }

        async function verifyToken() {
            if (!token) {
                showNotice('Lien invalide ou manquant.', 'error');
                submitBtn.disabled = true;
                return;
            }

            try {
                const response = await fetch('./api/password-reset.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'verify_token', token })
                });
                const result = await response.json();
                if (!result.success) {
                    showNotice(result.message || 'Lien expiré ou invalide.', 'error');
                    submitBtn.disabled = true;
                }
            } catch (error) {
                showNotice('Erreur lors de la vérification du lien.', 'error');
                submitBtn.disabled = true;
            }
        }

        document.getElementById('resetForm').addEventListener('submit', async (event) => {
            event.preventDefault();

            const password = document.getElementById('newPassword').value.trim();
            const confirm = document.getElementById('confirmPassword').value.trim();

            if (password.length < 6) {
                showNotice('Mot de passe trop court (min 6 caractères).', 'error');
                return;
            }

            if (password !== confirm) {
                showNotice('Les mots de passe ne correspondent pas.', 'error');
                return;
            }

            submitBtn.disabled = true;

            try {
                const response = await fetch('./api/password-reset.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'reset_password', token, password })
                });

                const result = await response.json();
                if (result.success) {
                    showNotice('✅ Mot de passe réinitialisé. Vous pouvez vous connecter.', 'success');
                } else {
                    showNotice(result.message || 'Erreur lors de la réinitialisation.', 'error');
                }
            } catch (error) {
                showNotice('Erreur lors de la réinitialisation.', 'error');
            } finally {
                submitBtn.disabled = false;
            }
        });

        verifyToken();
    </script>
</body>
</html>
